﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;


namespace TD_Find_Lib
{
	public static class TrySelect
	{
		public static void Select(Thing t, bool playSound = true)
		{
			if(t.def.selectable && t.Spawned)
				Find.Selector.Select(t, playSound);
		}
	}
}
